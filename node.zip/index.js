const express = require('express')
const jwt = require('jsonwebtoken')
const cors = require('cors')
const app = express()
const port = 3030;
const csv = require('csv-parser');
const fs = require('fs');
const someObject = require('./updatedmenu.json')
const bodyParser = require('body-parser');
const { ReadExcel } = require('../src/components/ReadExcel');
var XLSX = require("xlsx");
const cookieParser = require("cookie-parser");





app.use(cors())
app.use(express.json())
app.use(cookieParser());
// let result = []
let items = []
let realData = []
let headers = {}
let data = []
let guestCount
let row=[]
let col = []
let value=[]
let json1 = {}
let json2 = {}

let array2 = []
let result = {}; //(1)

const admin = {id:'myself', username:'saurav', password:'test123'}


app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.post('/result', (req, res) => {
  const menu = req.body
  items.push(menu)
  res.send('item is added in the array ')
  console.log('hi from result')
})



app.get('/', (req, res) => {
  res.setHeader('content-type', 'application/json');
  res.json(someObject.menu)
  res.status(200)
  res.end
  console.log(req.body, 'hello world')
  console.log('hello from main')
})

const verifyJWT = (req, res, next)=>{
  console.log(req)
  const token = req.headers[admin]
  if(!token){
    res.send('there is no-token')
  }
    else{
      jwt.verify(token, 'secret', (err, decoded)=>{
          if(err){
            console.log(err)
            res.json({auth:false, message:'authentication failed'})
          }   else{
            req.userId=decoded.id;
            next()
          }
      })
  }
}

const details =  {orderAdmin:admin}

// app.get('/login', verifyJWT, (req, res)=>{
// })

app.post('/login', (req, res)=>{
  console.log('--------------LOGIN request ')
  // res.setHeader('content-type', 'application/json');
  const user = {username:req.body.user, password:req.body.password}
  console.log(req.header)
  if(user.password==admin.password){
    const id= admin.id
    const token = jwt.sign({id}, 'secret', {
      expiresIn:300,
    })
res.json({auth:true, token:token, result:details})
  }
  else{
    res.json('Wrong UserName or Password') 
  }

  res.status(200)
  // res.send(user)
})


app.get('/api', (req, res) => {
  console.log('------------------------POST REQUEST')
  const checkItem = (item) => {
    return item.dishName.toLowerCase().includes(req.query.input)
  }
  const Filter = someObject.menu.filter(checkItem).slice(0 ,6)
  console.log('data sent ', Filter.map((item) => {
    return item.dishName
  }))
  res.send(Filter)
})



const ReeadExcel = (items) => {
  json1 = {}

  array2 = []
  data = []
  realData = []
  console.log('ReeadExcel funciton is running')
  var workbook = XLSX.readFile("react.xlsx");
  var sheet_name_list = workbook.SheetNames;
  console.log('sheet name is here ', sheet_name_list); // getting as Sheet1

  sheet_name_list.forEach(function (y) {
    var worksheet = workbook.Sheets[y];
    //getting the complete sheet
    // console.log('work sheet ', worksheet);



    var headers = {};
    var data = [];
    for (cellname in worksheet) {
      // array2 = []
      if (cellname[0] === "!") continue;
      //parse out the column, row, and value
      var col = cellname.substring(0, 1);
      // colData.push(col)
      // console.log('column ', col, '  ||   z is value ', z[1]);

      var row = parseInt(cellname.substring(1));
     
      // console.log('row ', row);

      var value = worksheet[cellname].v

      if (row == 1) {
        
        // Dishes.push(value)
      }
      // }


      //store header names
      if (row == 1) {
        headers[col] = value;
        items.forEach((val) => {
          if (headers[col].includes(val)) {
            console.log('hi from headerCol')
            // colValue.push(col)
          }
          // console.log('hello from ', val)  
        })
        // console.log('header col ' , headers[col]);
        // storing the header names
        continue;
      }

      if (!data[row]) data[row] = {};
      data[row][headers[col]] = value;
      // console.log('data ', '  header is here   ',[colData]);

      // colValue.forEach((val) => {
      //   if (col == val) {

      //     ingredients.push(value)
      //   }
        // console.log('ingredients  ', ingredients)
      // })
    }


    

    //drop those first two rows which are empty
    data.shift();
    data.shift();
    realData.push(data)
    items.forEach((foodName) => {
      // console.log('-----for each items ', foodName)
      let data1 = data.map((item) => { return item.ingredients })
      let data2 = realData[0].map((item, idx) => { return item[foodName] })
      let key = foodName
      json1[key] = json2
      // console.log('data 1 and data 2 ', data1 , data2)

      data1.map((val, idx) => {
        console.log('val is here ', val)
        if (!data2[idx] == 0
          // && !data1[idx]==undefined
          && val
          && !isNaN(data2[idx])
          && val !== ''
        ) {

          let key1 = val
          json2[key1] = {}
          json2[key1] = parseInt(data2[idx])
          // console.log('key1 is here ', key1)
          // console.log('=============')
        }
      });
      array2.push(json2);
      // console.log('json2 is here ', json2)

      json2 = {}
    });
  })
}




const TotalIng = (data, guestCount) => {
  console.log('total function', data, guestCount)
  result = {}
  data.forEach(basket => { //(2)
    for (let [key, value] of Object.entries(basket)) { //(3)
      let num = value * guestCount 
      if (result[key]) { //(4)
        console.log(num)
        result[key] += num; //(5)
      } else { //(6)
        result[key] = num;
      }
    }
  });
  console.log('result is here ', result)
  return result; //(7)
}

app.post('/api', async (req, res) => {
  items = req.body.menu
  guestCount = req.body.guestCount
  console.log(items)
    console.log(guestCount)
  res.setHeader('content-type', 'application/json');
  ReeadExcel(items)
  TotalIng(array2, guestCount)
  res.send({
    ingredients: json1,
    total: result
  })
  res.status(200)
})


app.post('/gen', (req, res)=>{
  console.log('--------GEN REQ')
  console.log(req.body.orders)
  TotalIng(array2, req.body.orders.guestCount)
  res.json(result)
})



//listen for request on port 3000, and as a callback function have the port listened on logged
app.listen(port, () => {
  console.log(`Server running at :${port}`);
});

// console.log(' this is the read stream ' , read)